import sys


def binance_candle_execute():
    print(sys.argv)
